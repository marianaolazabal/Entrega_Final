Blog sobre Python

Este proyecto fue desarrollado utilizando Anaconda, ya que en mi computadora del trabajo no tengo permisos de administradora y no podía realizar las configuraciones necesarias de forma directa.


Index

La página de inicio muestra la bienvenida al blog y una sección de post y ventas de vinilos. Incluye dos imágenes y permite iniciar sesión o registrarse.
En el navbar, al comienzo de la página, se puede acceder a About, Iniciar Sesión o Registrarse.


About

Presenta una descripción sobre quiénes somos y enlaces (inventados) a nuestras redes sociales.


Iniciar Sesión

Funcionalidad programada desde la app account.
Solicita username y password, y también permite acceder al registro en caso de no tener un usuario.


Registro

Redirige a la página donde se solicita un nombre de usuario, email, contraseña y confirmación de contraseña.
Desde allí se puede volver al login o utilizar el navbar para navegar al inicio, About o login.


Perfil

Al iniciar sesión, se accede a la vista post/perfil, donde se da la bienvenida al usuario y se muestran sus datos: nombre, apellido y email.
Si es la primera vez que inicia sesión luego de registrarse, solo se verán el usuario y el email.

Debajo de esta información aparece la opción Editar perfil.
Además, el navbar cambia para mostrar:

Inicio

- About
- Blog (para acceder a los posts de vinilos)
- Un botón para cerrar sesión
- Un botón llamado {nombre_usuario} (otra forma de acceder a Editar perfil)


Editar perfil

Permite modificar el email, nombre, apellido, subir una imagen (que luego se mostrará junto al nombre de usuario en el navbar) y cambiar la contraseña.


Cambiar contraseña

Página donde se solicita la contraseña actual, la nueva y la confirmación de la nueva para validar el cambio.


Blog

Muestra el título, autor (usuario que creó el post), fecha de publicación y estado (publicado o borrador) de cada entrada.

También permite:

- Ver detalles del post
- Editarlo
- Eliminarlo

Incluye un buscador que filtra por letra, palabra o número.
Para eliminar los filtros, basta con borrar el texto del buscador y presionar Enter.

También se ofrece la opción de Crear una nueva publicación.


Ver

Muestra los detalles del post:

- Título
- Autor
- Categoría
- Contenido
- Fecha de publicación
- Estado

Desde esta vista se puede regresar al listado.


Editar

Permite editar título, estado, contenido y categoría (seleccionando entre las disponibles).
Se puede cancelar para volver al listado o guardar los cambios.


Eliminar

Muestra una página pidiendo confirmación antes de borrar el post.
Si se cancela, se vuelve al listado sin eliminar nada; si se acepta, el post se elimina y se regresa al listado.


Crear nueva publicación

Solicita ingresar un título, seleccionar el estado de la publicación, escribir el contenido y elegir una categoría.


Logout

Redirige nuevamente al Index, mostrando únicamente las opciones About, Login o Registro.
